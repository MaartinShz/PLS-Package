checkinstall.shiny.plsda <-
function() {

  packages <- c("shiny","readxl", "dplyr", "plotly")
  install.packages(setdiff(packages, rownames(installed.packages())))

}
