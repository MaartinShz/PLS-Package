plsda <-
function(formula=NULL, data=NULL, ncomp=NULL, var.select = F){
  #check parameters
  #if(){}

  #cr�ation of the pls instance
  instance = list("ncomp"=ncomp)
  class(instance) = "PLSDA"

  return(instance)
}
