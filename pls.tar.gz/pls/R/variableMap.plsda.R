variableMap.plsda <-
function(object, comp1, comp2) {

  if (class(object)!="PLSDA") {
    stop("Object's class is not PLSDA")
  }

  plot(comp1,comp2,xlab="Comp.1",ylab="Comp.2", col =obj$ytarget , bty ="n")
  text(comp1,comp2,labels=obj$ytarget,cex=0.60)
  abline(h=0,v=0)

}
